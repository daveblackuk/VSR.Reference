# Define the log file path
$logFilePath = "$env:TEMP\vsr\vsr.log"

# Check if the log file exists
if (-Not (Test-Path $logFilePath)) {
    Write-Host "Log file not found: $logFilePath"
    exit
}

# Get the initial length of the log file
$length = (Get-Item $logFilePath).Length

# Start tailing the file
Write-Host "Tailing the log file: $logFilePath"
while ($true) {
    # Check if new content has been added to the log file
    $newLength = (Get-Item $logFilePath).Length
    if ($newLength -gt $length) {
        # Read the new content and output it
        $stream = [System.IO.File]::Open($logFilePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $stream.Seek($length, [System.IO.SeekOrigin]::Begin) | Out-Null
        $reader = New-Object System.IO.StreamReader($stream)
        while ($reader.Peek() -ge 0) {
            $line = $reader.ReadLine()
            Write-Output $line
        }
        $reader.Close()
        $stream.Close()

        # Update the file length
        $length = $newLength
    }

    # Pause briefly before checking again
    Start-Sleep -Milliseconds 500
}
